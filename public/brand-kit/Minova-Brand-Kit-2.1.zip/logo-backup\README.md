# Minova logo backup

Clean, unchanged backups of the logo files currently used across the Minova websites.

## Main

- `main/minova-symbol.svg` — Prism M symbol
- `main/minova-wordmark.svg` — MINOVA wordmark
- `main/minova-lockup.svg` — symbol and wordmark lockup
- `main/minova-favicon.svg` — Main website favicon

## Chromium

- `chromium/minova-wordmark-supplied.svg` — supplied `minova logo (1).svg`
- `chromium/chromium-wordmark-supplied.svg` — supplied `chromium.svg`
- `chromium/minova-browser-icon.png` — current Chromium website/product icon
- `chromium/minova-lockup-legacy.png` — previous combined lockup
- `chromium/minova-wordmark-legacy.png` — previous raster wordmark

The two supplied SVGs are preserved byte-for-byte and are the wordmarks used by the Chromium website header and footer.

## Cinema

- `cinema/minova-symbol.svg` — Cinema website symbol
- `cinema/minova-wordmark.png` — MINOVA wordmark
- `cinema/cinema-wordmark.png` — CINEMA wordmark
- `cinema/minova-cinema-lockup.png` — combined Cinema website lockup

Do not edit files in this folder. Copy an asset elsewhere before making changes.
